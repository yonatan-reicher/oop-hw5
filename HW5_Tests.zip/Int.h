//
// Created by יונדב on 30/03/2024.
//

#ifndef OOP_HW5_INT_H
#define OOP_HW5_INT_H

template<int N>
struct Int{
    static constexpr int value = N;
};

#endif //OOP_HW5_INT_H
