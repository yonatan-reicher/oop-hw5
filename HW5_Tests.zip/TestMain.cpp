//
// Created by יונדב on 30/03/2024.
//

#include "ConditionalTest.h"
#include "ListTest.h"
#include "EnumsTest.h"
#include "BoardCellTest.h"
#include "GameBoardTest.h"
#include "MoveVehicleTest.h"
#include "RushHourTest.h"
#include "FailTest.h"
#include <iostream>
using namespace std;

int main(){
    cout << "Success!" << endl;
    testFail();
    return 0;
}